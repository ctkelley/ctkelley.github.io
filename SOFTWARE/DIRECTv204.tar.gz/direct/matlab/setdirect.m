% Set the parameters for DIRECT. Some of them will be changed in the main
% program.
%
% Joerg Gablonsky, 10/31/00

DIReps     = 1.D-4;
DIRnumf    = 20000;
numberT    = 6000;
DIRJones   = 0;
DIRperc    = 0.01;
